package com.mycompany.inventorylogic.model;

public class PackagedProduct extends Product {

    public PackagedProduct(String productId, String productName,
                           double price, int stock, int reorderLevel) {

        super(productId, productName, price, stock, reorderLevel);
    }

    @Override
    public String getProductType() {
        return "Packaged";
    }
}