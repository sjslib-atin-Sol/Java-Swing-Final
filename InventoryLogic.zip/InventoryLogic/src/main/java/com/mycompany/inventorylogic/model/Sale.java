package com.mycompany.inventorylogic.model;

import java.time.LocalDate;

public class Sale {

    private String productName;
    private int quantity;
    private double totalAmount;
    private LocalDate saleDate;

    public Sale(String productName, int quantity, double totalAmount) {
        this.productName = productName;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
        this.saleDate = LocalDate.now();
    }

    public String getProductName() {
        return productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public LocalDate getSaleDate() {
        return saleDate;
    }

    @Override
    public String toString() {
        return productName + " | Quantity: " + quantity
                + " | Total: PHP " + totalAmount
                + " | Date: " + saleDate;
    }
}