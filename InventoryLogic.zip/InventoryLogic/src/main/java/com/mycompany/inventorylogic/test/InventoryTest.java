package com.mycompany.inventorylogic.test;

import com.mycompany.inventorylogic.InventoryLogic;
import com.mycompany.inventorylogic.model.Product;
import com.mycompany.inventorylogic.model.PackagedProduct;
import com.mycompany.inventorylogic.model.PerishableProduct;
import java.time.LocalDate;

public class InventoryTest {

    public static void main(String[] args) {

        InventoryLogic inventory = new InventoryLogic();

        Product p1 = new PackagedProduct(
                "P001", "Lucky Me Pancit Canton", 15, 50, 10);

        Product p2 = new PackagedProduct(
                "P002", "Canned Sardines", 25, 20, 5);

        Product p3 = new PerishableProduct(
                "P003", "Eggs", 9, 36, 12,
                LocalDate.of(2026, 12, 20));

        inventory.addProduct(p1);
        inventory.addProduct(p2);
        inventory.addProduct(p3);

        System.out.println("===== ALL PRODUCTS =====");

        for (Product product : inventory.getAllProducts()) {
            System.out.println(product);
        }

        System.out.println("\n===== SEARCH PRODUCT =====");
        System.out.println(inventory.searchProduct("Eggs"));

        System.out.println("\n===== EDIT PRODUCT =====");

        Product updatedProduct = new PackagedProduct(
                "P001", "Lucky Me Pancit Canton", 18, 60, 10);

        inventory.editProduct("P001", updatedProduct);

        System.out.println(inventory.searchProductById("P001"));

        System.out.println("\n===== RECORD SALE =====");

        inventory.recordSale("P001", 5);

        System.out.println("Sale recorded successfully.");

        System.out.println("\n===== REMOVE PRODUCT =====");

        inventory.removeProduct("P002");

        System.out.println("Product removed successfully.");

        System.out.println("\n===== DAILY REPORT =====");

        System.out.println(inventory.generateDailyReport());
    }
}