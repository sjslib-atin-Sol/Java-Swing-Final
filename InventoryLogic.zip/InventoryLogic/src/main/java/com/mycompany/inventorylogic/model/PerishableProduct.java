package com.mycompany.inventorylogic.model;

import java.time.LocalDate;

public class PerishableProduct extends Product {

    private LocalDate expirationDate;

    public PerishableProduct(String productId, String productName,
                             double price, int stock, int reorderLevel,
                             LocalDate expirationDate) {

        super(productId, productName, price, stock, reorderLevel);
        this.expirationDate = expirationDate;
    }

    public LocalDate getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(LocalDate expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Override
    public String getProductType() {
        return "Perishable";
    }

    @Override
    public String toString() {
        return super.toString()
                + " | Expiration Date: " + expirationDate;
    }
}