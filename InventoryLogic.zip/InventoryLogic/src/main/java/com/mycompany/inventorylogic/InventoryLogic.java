package com.mycompany.inventorylogic;

import java.util.ArrayList;
import java.time.LocalDate;

import com.mycompany.inventorylogic.model.Product;
import com.mycompany.inventorylogic.model.Sale;

public class InventoryLogic {

    private ArrayList<Product> products;
    private ArrayList<Sale> sales;

    public InventoryLogic() {
        products = new ArrayList<>();
        sales = new ArrayList<>();
    }

    public ArrayList<Product> getAllProducts() {
        return new ArrayList<>(products);
    }

    public void addProduct(Product product) {

        if (product == null) {
            throw new IllegalArgumentException("Product cannot be empty.");
        }

        if (searchProductById(product.getProductId()) != null) {
            throw new IllegalArgumentException("Product ID already exists.");
        }

        if (product.getPrice() < 0 || product.getStock() < 0
                || product.getReorderLevel() < 0) {
            throw new IllegalArgumentException("Invalid product values.");
        }

        products.add(product);
    }

    public Product searchProduct(String productName) {

        for (Product product : products) {
            if (product.getProductName().equalsIgnoreCase(productName)) {
                return product;
            }
        }

        return null;
    }

    public Product searchProductById(String productId) {

        for (Product product : products) {
            if (product.getProductId().equalsIgnoreCase(productId)) {
                return product;
            }
        }

        return null;
    }

    public void editProduct(String productId, Product updatedProduct) {

        for (int i = 0; i < products.size(); i++) {

            if (products.get(i).getProductId().equalsIgnoreCase(productId)) {

                if (updatedProduct == null
                        || !updatedProduct.getProductId().equalsIgnoreCase(productId)) {
                    throw new IllegalArgumentException("Invalid updated product.");
                }

                if (updatedProduct.getPrice() < 0
                        || updatedProduct.getStock() < 0
                        || updatedProduct.getReorderLevel() < 0) {
                    throw new IllegalArgumentException("Invalid product values.");
                }

                products.set(i, updatedProduct);
                return;
            }
        }

        throw new IllegalArgumentException("Product not found.");
    }

    public void removeProduct(String productId) {

        Product product = searchProductById(productId);

        if (product == null) {
            throw new IllegalArgumentException("Product not found.");
        }

        products.remove(product);
    }

    public ArrayList<Product> getLowStockProducts() {

        ArrayList<Product> lowStock = new ArrayList<>();

        for (Product product : products) {
            if (product.getStock() <= product.getReorderLevel()) {
                lowStock.add(product);
            }
        }

        return lowStock;
    }

    public void recordSale(String productId, int quantity) {

        Product product = searchProductById(productId);

        if (product == null) {
            throw new IllegalArgumentException("Product not found.");
        }

        if (quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }

        if (quantity > product.getStock()) {
            throw new IllegalArgumentException("Not enough stock.");
        }

        double total = product.getPrice() * quantity;

        product.setStock(product.getStock() - quantity);

        sales.add(new Sale(product.getProductName(), quantity, total));
    }

    public String generateDailyReport() {

        StringBuilder report = new StringBuilder();

        double totalSales = 0;
        int totalItemsSold = 0;

        report.append("===== DAILY SALES REPORT =====\n");
        report.append("Date: ").append(LocalDate.now()).append("\n\n");

        report.append("SALES:\n");

        for (Sale sale : sales) {

            if (sale.getSaleDate().equals(LocalDate.now())) {
                report.append(sale).append("\n");

                totalSales += sale.getTotalAmount();
                totalItemsSold += sale.getQuantity();
            }
        }

        report.append("\nTotal Items Sold: ").append(totalItemsSold);
        report.append("\nTotal Sales: PHP ").append(totalSales);

        report.append("\n\nLOW STOCK PRODUCTS:\n");

        for (Product product : getLowStockProducts()) {
            report.append(product).append("\n");
        }

        return report.toString();
    }
}