package com.mycompany.inventorylogic.model;

public abstract class Product {

    private String productId;
    private String productName;
    private double price;
    private int stock;
    private int reorderLevel;

    public Product(String productId, String productName,
                   double price, int stock, int reorderLevel) {
        this.productId = productId;
        this.productName = productName;
        this.price = price;
        this.stock = stock;
        this.reorderLevel = reorderLevel;
    }

    public String getProductId() {
        return productId;
    }

    public String getProductName() {
        return productName;
    }

    public double getPrice() {
        return price;
    }

    public int getStock() {
        return stock;
    }

    public int getReorderLevel() {
        return reorderLevel;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setReorderLevel(int reorderLevel) {
        this.reorderLevel = reorderLevel;
    }

    public abstract String getProductType();

    @Override
    public String toString() {
        return productId + " - " + productName
                + " | Type: " + getProductType()
                + " | Price: PHP " + price
                + " | Stock: " + stock
                + " | Reorder Level: " + reorderLevel;
    }
}