package com.mycompany.inventorylogic.model;

import java.time.LocalDate;

public class PerishableProduct extends Product {

    private LocalDate expirationDate;

    public PerishableProduct(String productId, String productName,
                             double price, int stock, int reorderLevel,
                             LocalDate expirationDate) {
        super(productId, productName, price, stock, reorderLevel);
        this.expirationDate = expirationDate;
    }

    public LocalDate getExpirationDate() { return expirationDate; }
    public void setExpirationDate(LocalDate expirationDate) { this.expirationDate = expirationDate; }

    @Override
    public String getProductType() {
        return "Perishable";
    }

    @Override
    public String getStatusAlert() {
        LocalDate today = LocalDate.now();
        boolean isExpired = expirationDate != null && expirationDate.isBefore(today);
        boolean isExpiringSoon = expirationDate != null && !isExpired && !expirationDate.isAfter(today.plusDays(3));

        if (isExpired) {
            return "EXPIRED (" + expirationDate + ")";
        } else if (isExpiringSoon && needsRestock()) {
            return "LOW STOCK & EXPIRING SOON (" + expirationDate + ")";
        } else if (isExpiringSoon) {
            return "EXPIRING SOON (" + expirationDate + ")";
        } else if (needsRestock()) {
            return "LOW STOCK (Reorder at " + getReorderLevel() + ")";
        }
        return "FRESH (Exp: " + expirationDate + ")";
    }

    @Override
    public String toString() {
        return super.toString() + " | Exp: " + expirationDate;
    }
}
