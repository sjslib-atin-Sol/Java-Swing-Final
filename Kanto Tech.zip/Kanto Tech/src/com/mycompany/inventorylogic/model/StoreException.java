package com.mycompany.inventorylogic.model;

public class StoreException extends Exception {
    public StoreException(String message) {
        super(message);
    }
}
