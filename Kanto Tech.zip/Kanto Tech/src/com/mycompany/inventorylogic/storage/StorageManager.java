package com.mycompany.inventorylogic.storage;

import com.mycompany.inventorylogic.model.*;
import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StorageManager {

    private final String productsFilePath;
    private final String salesFilePath;

    public StorageManager(String productsFilePath, String salesFilePath) {
        this.productsFilePath = productsFilePath;
        this.salesFilePath = salesFilePath;
    }

    public void saveProducts(List<Product> products) throws StoreException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(productsFilePath))) {
            for (Product p : products) {
                String exp = "";
                if (p instanceof PerishableProduct) {
                    LocalDate date = ((PerishableProduct) p).getExpirationDate();
                    exp = (date != null) ? date.toString() : "";
                }
                writer.println(String.join(",",
                        p.getProductId(),
                        p.getProductName().replace(",", " "),
                        p.getProductType(),
                        String.valueOf(p.getPrice()),
                        String.valueOf(p.getStock()),
                        String.valueOf(p.getReorderLevel()),
                        exp
                ));
            }
        } catch (IOException e) {
            throw new StoreException("Failed to save products: " + e.getMessage());
        }
    }

    public ArrayList<Product> loadProducts() throws StoreException {
        ArrayList<Product> loaded = new ArrayList<>();
        File file = new File(productsFilePath);
        if (!file.exists()) {
            return loaded;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length < 6) continue;

                String id = parts[0];
                String name = parts[1];
                String type = parts[2];
                double price = Double.parseDouble(parts[3]);
                int stock = Integer.parseInt(parts[4]);
                int reorder = Integer.parseInt(parts[5]);

                if ("Perishable".equalsIgnoreCase(type)) {
                    LocalDate expDate = (parts.length > 6 && !parts[6].isEmpty())
                            ? LocalDate.parse(parts[6]) : null;
                    loaded.add(new PerishableProduct(id, name, price, stock, reorder, expDate));
                } else {
                    loaded.add(new PackagedProduct(id, name, price, stock, reorder));
                }
            }
        } catch (Exception e) {
            throw new StoreException("Error reading products file: " + e.getMessage());
        }
        return loaded;
    }

    public void saveSales(List<Sale> sales) throws StoreException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(salesFilePath))) {
            for (Sale s : sales) {
                writer.println(String.join(",",
                        s.getProductName().replace(",", " "),
                        String.valueOf(s.getQuantity()),
                        String.valueOf(s.getTotalAmount()),
                        s.getSaleDate().toString()
                ));
            }
        } catch (IOException e) {
            throw new StoreException("Failed to save sales: " + e.getMessage());
        }
    }

    public ArrayList<Sale> loadSales() throws StoreException {
        ArrayList<Sale> loaded = new ArrayList<>();
        File file = new File(salesFilePath);
        if (!file.exists()) {
            return loaded;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",", -1);
                if (parts.length < 4) continue;

                String name = parts[0];
                int qty = Integer.parseInt(parts[1]);
                double total = Double.parseDouble(parts[2]);
                LocalDate date = LocalDate.parse(parts[3]);

                loaded.add(new Sale(name, qty, total, date));
            }
        } catch (Exception e) {
            throw new StoreException("Error reading sales file: " + e.getMessage());
        }
        return loaded;
    }
}
