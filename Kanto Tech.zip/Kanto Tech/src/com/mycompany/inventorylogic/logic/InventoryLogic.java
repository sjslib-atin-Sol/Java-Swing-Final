package com.mycompany.inventorylogic.logic;

import com.mycompany.inventorylogic.model.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class InventoryLogic {

    private ArrayList<Product> products;
    private ArrayList<Sale> sales;

    public InventoryLogic() {
        products = new ArrayList<>();
        sales = new ArrayList<>();
    }

    public ArrayList<Product> getAllProducts() {
        return new ArrayList<>(products);
    }

    public ArrayList<Sale> getAllSales() {
        return new ArrayList<>(sales);
    }

    public void setLoadedData(ArrayList<Product> loadedProducts, ArrayList<Sale> loadedSales) {
        this.products = (loadedProducts != null) ? loadedProducts : new ArrayList<>();
        this.sales = (loadedSales != null) ? loadedSales : new ArrayList<>();
    }

    public void addProduct(Product product) throws StoreException {
        if (product == null) {
            throw new StoreException("Product cannot be empty.");
        }
        if (product.getProductId().trim().isEmpty() || product.getProductName().trim().isEmpty()) {
            throw new StoreException("Product ID and Name are required.");
        }
        if (searchProductById(product.getProductId()) != null) {
            throw new StoreException("Product ID '" + product.getProductId() + "' already exists.");
        }
        if (product.getPrice() <= 0 || product.getStock() < 0 || product.getReorderLevel() < 0) {
            throw new StoreException("Price must be > 0, and Stock/Reorder Level cannot be negative.");
        }
        products.add(product);
    }

    public ArrayList<Product> searchProducts(String keyword) {
        ArrayList<Product> matches = new ArrayList<>();
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllProducts();
        }
        String lower = keyword.trim().toLowerCase();
        for (Product product : products) {
            if (product.getProductId().toLowerCase().contains(lower)
                    || product.getProductName().toLowerCase().contains(lower)) {
                matches.add(product);
            }
        }
        return matches;
    }

    public Product searchProductById(String productId) {
        for (Product product : products) {
            if (product.getProductId().equalsIgnoreCase(productId.trim())) {
                return product;
            }
        }
        return null;
    }

    public void editProduct(String productId, Product updatedProduct) throws StoreException {
        for (int i = 0; i < products.size(); i++) {
            if (products.get(i).getProductId().equalsIgnoreCase(productId)) {
                if (updatedProduct == null || !updatedProduct.getProductId().equalsIgnoreCase(productId)) {
                    throw new StoreException("Cannot change Product ID during edit.");
                }
                if (updatedProduct.getPrice() <= 0 || updatedProduct.getStock() < 0 || updatedProduct.getReorderLevel() < 0) {
                    throw new StoreException("Price must be > 0, and Stock/Reorder Level cannot be negative.");
                }
                products.set(i, updatedProduct);
                return;
            }
        }
        throw new StoreException("Product ID '" + productId + "' not found.");
    }

    public void removeProduct(String productId) throws StoreException {
        Product product = searchProductById(productId);
        if (product == null) {
            throw new StoreException("Product not found.");
        }
        products.remove(product);
    }

    public ArrayList<Product> getAlertProducts() {
        ArrayList<Product> alerts = new ArrayList<>();
        for (Product product : products) {
            String status = product.getStatusAlert();
            if (!status.startsWith("OK") && !status.startsWith("FRESH")) {
                alerts.add(product);
            }
        }
        return alerts;
    }

    public void recordSale(String productId, int quantity) throws StoreException {
        Product product = searchProductById(productId);
        if (product == null) {
            throw new StoreException("Select a valid product to record a sale.");
        }
        if (quantity <= 0) {
            throw new StoreException("Sale quantity must be greater than zero.");
        }
        if (quantity > product.getStock()) {
            throw new StoreException("Not enough stock. Available: " + product.getStock());
        }

        double total = product.getPrice() * quantity;
        product.setStock(product.getStock() - quantity);
        sales.add(new Sale(product.getProductName(), quantity, total));
    }

    public String generateDailyReport() {
        StringBuilder report = new StringBuilder();
        double totalSales = 0;
        int totalItemsSold = 0;

        report.append("=========================================\n");
        report.append("      SARI-SARI STORE DAILY REPORT       \n");
        report.append("=========================================\n");
        report.append("Date: ").append(LocalDate.now()).append("\n\n");

        report.append("--- TODAY'S SALES ---\n");
        boolean hasSales = false;
        for (Sale sale : sales) {
            if (sale.getSaleDate().equals(LocalDate.now())) {
                report.append("• ").append(sale).append("\n");
                totalSales += sale.getTotalAmount();
                totalItemsSold += sale.getQuantity();
                hasSales = true;
            }
        }
        if (!hasSales) {
            report.append("No sales recorded today.\n");
        }

        report.append("\nTotal Items Sold: ").append(totalItemsSold).append("\n");
        report.append("Total Revenue:    PHP ").append(String.format("%.2f", totalSales)).append("\n\n");

        report.append("--- LOW STOCK & EXPIRATION ALERTS ---\n");
        ArrayList<Product> alerts = getAlertProducts();
        if (alerts.isEmpty()) {
            report.append("All products are well-stocked and fresh.\n");
        } else {
            for (Product product : alerts) {
                report.append("• ").append(product).append("\n");
            }
        }

        return report.toString();
    }
}
