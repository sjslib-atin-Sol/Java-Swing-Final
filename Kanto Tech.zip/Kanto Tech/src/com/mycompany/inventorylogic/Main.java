package com.mycompany.inventorylogic;

import com.mycompany.inventorylogic.logic.InventoryLogic;
import com.mycompany.inventorylogic.storage.StorageManager;
import com.mycompany.inventorylogic.ui.MainScreen;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            InventoryLogic logic = new InventoryLogic();
            StorageManager storage = new StorageManager("products.csv", "sales.csv");
            MainScreen screen = new MainScreen(logic, storage);
            screen.setVisible(true);
        });
    }
}
