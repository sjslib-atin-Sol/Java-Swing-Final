package com.mycompany.inventorylogic.ui;

import javax.swing.*;
import java.awt.*;

public class ReportScreen extends JDialog {

    public static final Color BG_COLOR = new Color(245, 247, 250);
    public static final Color PRIMARY_COLOR = new Color(33, 97, 140);
    public static final Font HEADER_FONT = new Font("Arial", Font.BOLD, 18);
    public static final Font MONO_FONT = new Font("Monospaced", Font.PLAIN, 13);

    public ReportScreen(JFrame parent, String reportText) {
        super(parent, "Daily Store Report", true);
        setSize(580, 460);
        setLocationRelativeTo(parent);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(BG_COLOR);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("DAILY INVENTORY & SALES REPORT", SwingConstants.CENTER);
        title.setFont(HEADER_FONT);
        title.setForeground(PRIMARY_COLOR);
        panel.add(title, BorderLayout.NORTH);

        JTextArea textArea = new JTextArea(reportText);
        textArea.setFont(MONO_FONT);
        textArea.setEditable(false);
        textArea.setMargin(new Insets(10, 10, 10, 10));
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());
        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottom.setBackground(BG_COLOR);
        bottom.add(btnClose);
        panel.add(bottom, BorderLayout.SOUTH);

        add(panel);
    }
}
