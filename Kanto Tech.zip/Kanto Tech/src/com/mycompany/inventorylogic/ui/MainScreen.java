package com.mycompany.inventorylogic.ui;

import com.mycompany.inventorylogic.logic.InventoryLogic;
import com.mycompany.inventorylogic.model.*;
import com.mycompany.inventorylogic.storage.StorageManager;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class MainScreen extends JFrame {

    public static final Color BG_COLOR = new Color(245, 247, 250);
    public static final Color PRIMARY_COLOR = new Color(33, 97, 140);
    public static final Color SUCCESS_COLOR = new Color(30, 132, 73);
    public static final Color ERROR_COLOR = new Color(192, 57, 43);
    public static final Font TITLE_FONT = new Font("Arial", Font.BOLD, 22);
    public static final Font LABEL_FONT = new Font("Arial", Font.BOLD, 13);
    public static final Font STATUS_FONT = new Font("Arial", Font.BOLD, 13);

    private final InventoryLogic logic;
    private final StorageManager storage;

    private JTextField txtProductId;
    private JTextField txtProductName;
    private JComboBox<String> cmbType;
    private JTextField txtPrice;
    private JTextField txtStock;
    private JTextField txtReorderLevel;
    private JTextField txtExpirationDate;
    private JTextField txtSearch;
    private JTextField txtSaleQty;

    private JTable productTable;
    private DefaultTableModel tableModel;

    private JButton btnAdd;
    private JButton btnEdit;
    private JButton btnDelete;
    private JButton btnClear;
    private JButton btnSearch;
    private JButton btnRecordSale;
    private JButton btnReport;

    private JLabel lblStatus;

    public MainScreen(InventoryLogic logic, StorageManager storage) {
        this.logic = logic;
        this.storage = storage;

        setTitle("Sari-Sari Store Inventory System");
        setSize(1050, 680);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new BorderLayout(12, 12));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        JLabel title = new JLabel("SARI-SARI STORE INVENTORY SYSTEM", SwingConstants.CENTER);
        title.setFont(TITLE_FONT);
        title.setForeground(PRIMARY_COLOR);
        mainPanel.add(title, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(4, 4, 10, 8));
        inputPanel.setBackground(BG_COLOR);
        inputPanel.setBorder(BorderFactory.createTitledBorder("Product Details"));

        txtProductId = new JTextField();
        txtProductName = new JTextField();
        cmbType = new JComboBox<>(new String[]{"Packaged", "Perishable"});
        txtPrice = new JTextField();
        txtStock = new JTextField();
        txtReorderLevel = new JTextField();
        txtExpirationDate = new JTextField();
        txtExpirationDate.setEnabled(false);

        inputPanel.add(createLabel("Product ID:"));
        inputPanel.add(txtProductId);
        inputPanel.add(createLabel("Product Name:"));
        inputPanel.add(txtProductName);

        inputPanel.add(createLabel("Type:"));
        inputPanel.add(cmbType);
        inputPanel.add(createLabel("Price (PHP):"));
        inputPanel.add(txtPrice);

        inputPanel.add(createLabel("Stock on Hand:"));
        inputPanel.add(txtStock);
        inputPanel.add(createLabel("Reorder Level:"));
        inputPanel.add(txtReorderLevel);

        inputPanel.add(createLabel("Expiration (YYYY-MM-DD):"));
        inputPanel.add(txtExpirationDate);
        inputPanel.add(new JLabel(""));
        inputPanel.add(new JLabel(""));

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 5));
        buttonPanel.setBackground(BG_COLOR);

        btnAdd = new JButton("Add Product");
        btnAdd.setEnabled(false);
        btnEdit = new JButton("Update Selected");
        btnDelete = new JButton("Delete Selected");
        btnClear = new JButton("Clear Form");
        btnReport = new JButton("Daily Report");

        buttonPanel.add(btnAdd);
        buttonPanel.add(btnEdit);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnReport);

        JPanel actionBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        actionBar.setBackground(BG_COLOR);
        actionBar.setBorder(BorderFactory.createTitledBorder("Quick Search & Point of Sale"));

        txtSearch = new JTextField(16);
        btnSearch = new JButton("Search / Reset");
        txtSaleQty = new JTextField(6);
        btnRecordSale = new JButton("Record Sale (Selected)");

        actionBar.add(createLabel("Search Name/ID:"));
        actionBar.add(txtSearch);
        actionBar.add(btnSearch);
        actionBar.add(Box.createHorizontalStrut(25));
        actionBar.add(createLabel("Sale Qty:"));
        actionBar.add(txtSaleQty);
        actionBar.add(btnRecordSale);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Product Name", "Type", "Price (PHP)", "Stock", "Reorder", "Status Alert"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        productTable = new JTable(tableModel);
        productTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(productTable);

        JPanel topControls = new JPanel(new BorderLayout(5, 5));
        topControls.setBackground(BG_COLOR);
        topControls.add(inputPanel, BorderLayout.NORTH);
        topControls.add(buttonPanel, BorderLayout.CENTER);
        topControls.add(actionBar, BorderLayout.SOUTH);

        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(BG_COLOR);
        centerPanel.add(topControls, BorderLayout.NORTH);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(centerPanel, BorderLayout.CENTER);

        lblStatus = new JLabel("System Ready");
        lblStatus.setFont(STATUS_FONT);
        lblStatus.setForeground(PRIMARY_COLOR);
        mainPanel.add(lblStatus, BorderLayout.SOUTH);

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("Menu");
        JMenuItem reportItem = new JMenuItem("Daily Report");
        JMenuItem exitItem = new JMenuItem("Exit");
        menu.add(reportItem);
        menu.add(exitItem);
        menuBar.add(menu);
        setJMenuBar(menuBar);

        setupListeners(exitItem, reportItem);
        loadInitialData();
        add(mainPanel);
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(LABEL_FONT);
        return lbl;
    }

    private void setStatus(String message, Color color) {
        lblStatus.setText(message);
        lblStatus.setForeground(color);
    }

    private void loadInitialData() {
        try {
            logic.setLoadedData(storage.loadProducts(), storage.loadSales());
            refreshTable(logic.getAllProducts());
            setStatus("Loaded " + logic.getAllProducts().size() + " product(s) from file.", SUCCESS_COLOR);
        } catch (StoreException e) {
            setStatus(e.getMessage(), ERROR_COLOR);
        }
    }

    private void saveAllData() {
        try {
            storage.saveProducts(logic.getAllProducts());
            storage.saveSales(logic.getAllSales());
        } catch (StoreException e) {
            setStatus(e.getMessage(), ERROR_COLOR);
        }
    }

    private void refreshTable(List<Product> list) {
        tableModel.setRowCount(0);
        for (Product p : list) {
            tableModel.addRow(new Object[]{
                    p.getProductId(),
                    p.getProductName(),
                    p.getProductType(),
                    String.format("%.2f", p.getPrice()),
                    p.getStock(),
                    p.getReorderLevel(),
                    p.getStatusAlert()
            });
        }
    }

    private void clearForm() {
        txtProductId.setText("");
        txtProductName.setText("");
        cmbType.setSelectedIndex(0);
        txtPrice.setText("");
        txtStock.setText("");
        txtReorderLevel.setText("");
        txtExpirationDate.setText("");
        txtProductId.setEnabled(true);
        productTable.clearSelection();
    }

    private Product buildProductFromForm() throws StoreException {
        String id = txtProductId.getText().trim();
        String name = txtProductName.getText().trim();
        String type = (String) cmbType.getSelectedItem();

        double price;
        int stock;
        int reorder;
        try {
            price = Double.parseDouble(txtPrice.getText().trim());
            stock = Integer.parseInt(txtStock.getText().trim());
            reorder = Integer.parseInt(txtReorderLevel.getText().trim());
        } catch (NumberFormatException ex) {
            throw new StoreException("Price, Stock, and Reorder Level must be valid numbers.");
        }

        if ("Perishable".equals(type)) {
            String expText = txtExpirationDate.getText().trim();
            if (expText.isEmpty()) {
                throw new StoreException("Expiration date (YYYY-MM-DD) is required for Perishable items.");
            }
            try {
                LocalDate expDate = LocalDate.parse(expText);
                return new PerishableProduct(id, name, price, stock, reorder, expDate);
            } catch (DateTimeParseException ex) {
                throw new StoreException("Invalid date format. Use YYYY-MM-DD (e.g., 2026-12-20).");
            }
        } else {
            return new PackagedProduct(id, name, price, stock, reorder);
        }
    }

        private void updateAddButtonState() {
        boolean filled = !txtProductId.getText().trim().isEmpty()
                && !txtProductName.getText().trim().isEmpty()
                && !txtPrice.getText().trim().isEmpty()
                && !txtStock.getText().trim().isEmpty()
                && !txtReorderLevel.getText().trim().isEmpty();
        btnAdd.setEnabled(filled && txtProductId.isEnabled());
    }

    private void setupListeners(JMenuItem exitItem, JMenuItem reportItem) {
        DocumentListener formWatcher = new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { updateAddButtonState(); }
            public void removeUpdate(DocumentEvent e) { updateAddButtonState(); }
            public void changedUpdate(DocumentEvent e) { updateAddButtonState(); }
        };

        txtProductId.getDocument().addDocumentListener(formWatcher);
        txtProductName.getDocument().addDocumentListener(formWatcher);
        txtPrice.getDocument().addDocumentListener(formWatcher);
        txtStock.getDocument().addDocumentListener(formWatcher);
        txtReorderLevel.getDocument().addDocumentListener(formWatcher);

        cmbType.addActionListener(e -> {
            boolean isPerishable = "Perishable".equals(cmbType.getSelectedItem());
            txtExpirationDate.setEnabled(isPerishable);
            if (!isPerishable) txtExpirationDate.setText("");
        });

        productTable.getSelectionModel().addListSelectionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row >= 0) {
                String id = (String) tableModel.getValueAt(row, 0);
                Product p = logic.searchProductById(id);
                if (p != null) {
                    txtProductId.setText(p.getProductId());
                    txtProductId.setEnabled(false);
                    txtProductName.setText(p.getProductName());
                    cmbType.setSelectedItem(p.getProductType());
                    txtPrice.setText(String.valueOf(p.getPrice()));
                    txtStock.setText(String.valueOf(p.getStock()));
                    txtReorderLevel.setText(String.valueOf(p.getReorderLevel()));
                    if (p instanceof PerishableProduct && ((PerishableProduct) p).getExpirationDate() != null) {
                        txtExpirationDate.setText(((PerishableProduct) p).getExpirationDate().toString());
                    } else {
                        txtExpirationDate.setText("");
                    }
                    updateAddButtonState();
                }
            }
        });

        btnAdd.addActionListener(e -> {
            try {
                Product p = buildProductFromForm();
                logic.addProduct(p);
                saveAllData();
                refreshTable(logic.getAllProducts());
                clearForm();
                setStatus("Added product: " + p.getProductName(), SUCCESS_COLOR);
            } catch (StoreException ex) {
                setStatus("Error: " + ex.getMessage(), ERROR_COLOR);
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnEdit.addActionListener(e -> {
            try {
                String id = txtProductId.getText().trim();
                Product updated = buildProductFromForm();
                logic.editProduct(id, updated);
                saveAllData();
                refreshTable(logic.getAllProducts());
                clearForm();
                setStatus("Updated product: " + updated.getProductName(), SUCCESS_COLOR);
            } catch (StoreException ex) {
                setStatus("Error: " + ex.getMessage(), ERROR_COLOR);
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Edit Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnDelete.addActionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row < 0) {
                setStatus("Select a product from the table first.", ERROR_COLOR);
                return;
            }
            String id = (String) tableModel.getValueAt(row, 0);
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete product " + id + "?",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION
            );
            if (confirm == JOptionPane.YES_OPTION) {
                try {
                    logic.removeProduct(id);
                    saveAllData();
                    refreshTable(logic.getAllProducts());
                    clearForm();
                    setStatus("Deleted product: " + id, SUCCESS_COLOR);
                } catch (StoreException ex) {
                    setStatus("Error: " + ex.getMessage(), ERROR_COLOR);
                }
            }
        });

        btnClear.addActionListener(e -> {
            clearForm();
            setStatus("Form cleared.", PRIMARY_COLOR);
        });

        btnSearch.addActionListener(e -> {
            List<Product> results = logic.searchProducts(txtSearch.getText());
            refreshTable(results);
            setStatus("Found " + results.size() + " matching product(s).", PRIMARY_COLOR);
        });

        btnRecordSale.addActionListener(e -> {
            int row = productTable.getSelectedRow();
            if (row < 0) {
                setStatus("Select a product from the table to record a sale.", ERROR_COLOR);
                return;
            }
            String id = (String) tableModel.getValueAt(row, 0);
            try {
                int qty = Integer.parseInt(txtSaleQty.getText().trim());
                logic.recordSale(id, qty);
                saveAllData();
                refreshTable(logic.getAllProducts());
                txtSaleQty.setText("");
                setStatus("Sale recorded for product " + id + " (Qty: " + qty + ").", SUCCESS_COLOR);
            } catch (NumberFormatException ex) {
                setStatus("Enter a valid whole number for Sale Qty.", ERROR_COLOR);
            } catch (StoreException ex) {
                setStatus("Error: " + ex.getMessage(), ERROR_COLOR);
                JOptionPane.showMessageDialog(this, ex.getMessage(), "Sale Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnReport.addActionListener(e -> {
            ReportScreen dialog = new ReportScreen(this, logic.generateDailyReport());
            dialog.setVisible(true);
            setStatus("Viewed Daily Report.", PRIMARY_COLOR);
        });

        reportItem.addActionListener(e -> btnReport.doClick());

        exitItem.addActionListener(e -> {
            int choice = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to exit?",
                    "Confirm Exit",
                    JOptionPane.YES_NO_OPTION
            );
            if (choice == JOptionPane.YES_OPTION) {
                dispose();
            }
        });
    }
}

